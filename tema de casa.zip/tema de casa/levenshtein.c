#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// Funcția care returnează valoarea minimă dintre trei numere întregi
int min(int a, int b, int c) {
    if (a <= b && a <= c) return a;
    if (b <= a && b <= c) return b;
    return c;
}

// Funcția care calculează distanța Levenshtein
int levenshtein_distance(const char *s1, const char *s2) {
    int m = strlen(s1);
    int n = strlen(s2);
    int **dp = (int **)malloc((m + 1) * sizeof(int *));
    for (int i = 0; i <= m; i++) {
        dp[i] = (int *)malloc((n + 1) * sizeof(int));
    }

    for (int i = 0; i <= m; i++) {
        dp[i][0] = i;
    }
    for (int j = 0; j <= n; j++) {
        dp[0][j] = j;
    }

    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1];
            } else {
                dp[i][j] = 1 + min(dp[i - 1][j],    // ștergere
                                   dp[i][j - 1],    // inserare
                                   dp[i - 1][j - 1]); // substituire
            }
        }
    }

    int result = dp[m][n];
    for (int i = 0; i <= m; i++) {
        free(dp[i]);
    }
    free(dp);

    return result;
}

// Funcția pentru generarea unui șir aleator de lungime dată
char* generate_random_string(int length) {
    char *str = (char *)malloc((length + 1) * sizeof(char));
    const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (int i = 0; i < length; i++) {
        int key = rand() % (int)(sizeof(charset) - 1);
        str[i] = charset[key];
    }
    str[length] = '\0';
    return str;
}

// Funcția principală
int main() {
    // Testul specific dat
    const char *cod_invalid = "fnuc(myFuncion";
    const char *cod_valid = "func(myFunction)";

    int numar_minim_operatii = levenshtein_distance(cod_invalid, cod_valid);
    printf("Numarul minim de operatii necesare pentru fnuc(myFuncion -> func(myFunction)): %d\n", numar_minim_operatii);

    // Teste cu date mari aleatorii
    srand(time(NULL)); // Inițializează generatorul de numere aleatorii

    int numar_teste = 5; // Numărul de teste
    int lungime_sir = 1000; // Lungimea șirurilor aleatorii

    for (int i = 0; i < numar_teste; i++) {
        char *sir_aleator1 = generate_random_string(lungime_sir);
        char *sir_aleator2 = generate_random_string(lungime_sir);

        int distanta = levenshtein_distance(sir_aleator1, sir_aleator2);
        printf("Test %d: Distanta Levenshtein intre doua siruri de lungime %d este: %d\n", i + 1, lungime_sir, distanta);

        free(sir_aleator1);
        free(sir_aleator2);
    }

    return 0;
}
